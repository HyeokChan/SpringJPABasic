package jpabasic.jpaBasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
